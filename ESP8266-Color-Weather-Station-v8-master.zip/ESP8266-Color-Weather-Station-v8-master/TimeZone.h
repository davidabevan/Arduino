const char TimeZoneConfig[] = R"=====(
<label><br/>Enter city for time zone settings:<br/>
Valid values are Boston, New York, Louisville, <br/>
Chicago, Mountain, Arizona-DST, Arizona-noDST, <br/>
Pacific, Alaska, Hawaii, Tokyo, Sydney, and <br/>
Zurich. <br/>
Any other entry will cause the time setting to revert to GMT.<br/>
</label
)=====";

