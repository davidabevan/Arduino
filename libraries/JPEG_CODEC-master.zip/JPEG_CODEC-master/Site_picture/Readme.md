All the pictures that Readme.md need
