##New picture examples


2 new pictures for smaller screen... They should be 0k for [ILI9341](https://github.com/fredericplante/Adafruit_ILI9341)
 
  + [Splash.jpg](https://github.com/fredericplante/JPEGDecoder/blob/master/examples/TFT_SPIFFS_jpg_v3/data/Splash.jpg)
  
  + [Player.JPG](https://github.com/fredericplante/JPEGDecoder/blob/master/examples/TFT_SPIFFS_jpg_v3/data/Player.JPG)
    
Both are 320x240 JPEG
  
  
*They require to be stored on flash using the "ESP8266 sketch data upload" found in the "tool" section.
