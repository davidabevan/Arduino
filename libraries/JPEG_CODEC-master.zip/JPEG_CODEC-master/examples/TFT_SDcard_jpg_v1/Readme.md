1. Latest version, work with ESP8266.

2. Don't forget to set your User_Confi.h file to reflect the SD card need.

3. Confgure the SD cs pin at line# 80

4. Configure TFT cs at line# 60 and dc at line# 59

5. don't forget to get the Adafruit_ILI9341 libraries from:

https://github.com/fredericplante/Adafruit_ILI9341
