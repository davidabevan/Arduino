<img src="https://github.com/fredericplante/JPEGDecoder/blob/master/Site_picture/construction.jpg" width="50%"/>

[EOF]
