I still made a Bypass so it will compile and upload, but it will simply say that it won't work with ESP, on the Serial port. 

If you use this sketch with Mega256 or Due , it will work just fine.
