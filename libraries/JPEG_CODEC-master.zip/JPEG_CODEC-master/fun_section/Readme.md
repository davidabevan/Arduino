#The fun section.

This section will hide ideas from the main section that are not in direct link with
learnig how to use the JPEGDecoder libraries, but are more example of the real life 
stuff that you can do with it.

I've put up the root of what is to come, I must finish up some setup in the main 
section to do every thing that I want to put up here.

<img src="https://github.com/fredericplante/JPEGDecoder/blob/master/Site_picture/construction.jpg" width="50%"/>

[EOF]
