1 minutes [Video of the project](https://www.youtube.com/embed/QwVgXGCW2NE), Sorry bad quality and no sound,
I will do better soon.

[!["From Serial camera OV528 to ILI9364 SPI TFT 2,4 screen, using ESP8266."](http://img.youtube.com/vi/QwVgXGCW2NE/0.jpg)](http://www.youtube.com/watch?v=QwVgXGCW2NE "From Serial camera OV528 to ILI9364 SPI TFT 2,4 screen, using ESP8266.")

<img src="https://github.com/fredericplante/JPEGDecoder/blob/master/Site_picture/construction.jpg" width="50%"/>

[EOF]
