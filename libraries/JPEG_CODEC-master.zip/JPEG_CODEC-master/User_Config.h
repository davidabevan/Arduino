// Comment out the line below if you are not using an SD Card to store the JPEGs
// Commenting out the line is NOT essential but will save some FLASH space if
// SD Card access is not needed.

//#define USE_SD_CARD
#define USE_SPIFFS
#define USE_ILI9341
//#define USE_HX8357
//#define USE_SERIAL