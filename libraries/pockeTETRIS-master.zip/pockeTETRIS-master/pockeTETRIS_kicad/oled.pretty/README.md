# Battery_Holders.pretty

This repository contains KiCad footprints (.kicad_mod) for various battery holders and associated components.
