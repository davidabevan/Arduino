#MOVED  to https://github.com/fredericplante/JPEG_CODEC

Weel I don't know how and why wome thing strang happen to my git, and this has disapeare. Since i'm a disciplined
persone, I've done back up last night and since I have this unfortunate opportunity, I planted a new root as this 
address: https://github.com/fredericplante/JPEG_CODEC

It's been a while I was planing to intreduce the coder part, now this is a opprtunaty I can't miss.

See you on the other side.
