                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2172068
2.4" & 2.8" TFT Desktop stand by smily77 is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

Update 1: There was the wish for the same in 2.8" as the same display is available in this, a bit bigger, size. I added the files. (The bottom cover is the same)

With a small cheap TFT and an Arduino or ESP8266 many useful displays for your desktop can be made. Starting from ordinary clocks or weather stations also ideas like a display for the actual exchange rates, word clock, train schedule or even the time for the journey home can be found in the Internet. 

But it's all the same, if your are a "maker" you can't use your inventions in the living room, the office, etc. unless you give it a professional appearance - Who like to display a "home brew" thing?

This very simple stand allows to cover your 2.4 TFT (based on a ILI9341)  and  a Wemos mini ESP8266 board with an appearance like bought from a gadget dealer - without any "home brew" touch.

The TFT, the ESP8266 and the two covers stick together without any glue or screws. As an example i used the color weather station of Dani Eichhorn  - https://blog.squix.org/2016/10/esp8266-weather-station-color-code-published.html (Note I used a slightly different TFT, a TJCTM24024-SPI which has the same electronics but is 2.4" instead of 2.2".)




 

# Print Settings

Printer Brand: FlashForge
Printer: Creator Pro
Rafts: No
Supports: Yes
Resolution: 0.2mm
Infill: 20%

# Post-Printing

## Finishing

To become a real "factory made" appearance a little bit of sanding is required  

# How I Designed This

The entire design is done with Tinkercad